package edu.lab3;

public class Main {

    public static void main(String[] args) {
        CPerson osoba = new CPerson("Ja","Ty", 2000, 31345678901L);
    }
}
