package edu.lab7;

import javax.swing.*;

public class CCubicRoot {
    public void CCubicRoot(double number, double precision, JTextArea textArea){

    }
    public Double calculate(){
        return null;
    }
}
