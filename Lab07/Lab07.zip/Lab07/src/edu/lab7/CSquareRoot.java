package edu.lab7;

import javax.swing.*;

public class CSquareRoot extends CRoot{
    public CSquareRoot(double number, double precision, JTextArea textArea){
        this.number = super(number);
        this.precision = super(precision);
        this.textArea = super(textArea);
    }
    public Double calculate(){
        return null;
    }
}
