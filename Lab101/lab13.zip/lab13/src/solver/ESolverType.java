package solver;

public enum ESolverType {
    FIRST_ORDER, SECOND_ORDER, FOURTH_ORDER;
}
