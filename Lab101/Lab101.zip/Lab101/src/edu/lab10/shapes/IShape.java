package edu.lab10.shapes;

public interface IShape extends IDrawable, ISelectable, IMovable{


}
