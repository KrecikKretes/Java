package edu.lab10.shapes;

public interface ISelectable {

    boolean select(int xk, int yk);

}
