package edu.lab10.shapes;

import java.awt.*;

public interface IDrawable{
    void draw(Graphics graphics, boolean selected);


}