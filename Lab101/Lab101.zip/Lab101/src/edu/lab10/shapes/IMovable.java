package edu.lab10.shapes;

public interface IMovable {

    void moveBy(int dx, int dy);
    void moveTo(int x, int y);

}
